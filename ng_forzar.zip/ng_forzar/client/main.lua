-- Framework

ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

-- Locales 

local NP = {}
local time = 120
local job = nil

blip = nil 
blips = {}

-- Job Events 

AddEventHandler('playerSpawned', function(spawn)
	TriggerServerEvent('forzar:getJob')
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  	TriggerServerEvent('forzar:getJob')
end)

TriggerServerEvent('forzar:getJob')

RegisterNetEvent('forzar:setJob')
AddEventHandler('forzar:setJob',function(jobResult)
	job = jobResult
end)

-- Events

RegisterNetEvent('forzar:sendNotify')
AddEventHandler('forzar:sendNotify', function(type, data, length)
	if job == 'police' then 
		SendNUIMessage({action = 'display', style = type, info = data, length = length})
		PlaySound(-1, "Event_Start_Text", "GTAO_FM_Events_Soundset", 0, 0, 1)
	end
end)

RegisterNetEvent('forzar:setBlip')
AddEventHandler('forzar:setBlip', function(x, y, z)
	if job == 'police' then 
		blip = AddBlipForCoord(x, y, z)
        SetBlipSprite(blip, 523)
        SetBlipScale(blip, 0.6)
        SetBlipColour(blip, 4)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString('Robo de vehiculo')
        EndTextCommandSetBlipName(blip)
        table.insert(blips, blip)
        Wait(time * 1000)
        for i, blip in pairs(blips) do 
            RemoveBlip(blip)
		end
	end
end)

RegisterCommand('forzar', function()
	local ply = PlayerPedId()
	local plyv = GetVehiclePedIsIn(ply)
	local plyl = GetStreetNameFromHashKey(GetStreetNameAtCoord(table.unpack(GetEntityCoords(ply, true))))
	local x, y, z = table.unpack(GetEntityCoords(ply, true))
	local vehc = GetVehicleColours(plyv)
	vehc = Config.Colors[tostring(vehc)]
	local vehm = GetDisplayNameFromVehicleModel(GetEntityModel(plyv))
	if IsPedInAnyVehicle(ply) then 
		TriggerServerEvent('forzar:sendNotify', vehm, vehc, plyl)
		TriggerEvent('forzar:setBlip', x, y, z)
		print("enviado")
	else 
		print("Debes estar en un vehículo")
		ESX.ShowNotification('Debes estar en un vehículo')
	end
end)