-- Framework

ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

-- Job Events 

RegisterServerEvent('forzar:getJob')
AddEventHandler('forzar:getJob',function()
	local xPlayers = ESX.GetPlayers()
	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayers[i] == source then
			TriggerClientEvent('forzar:setJob', xPlayers[i], xPlayer.job.name)
		end
	end
end)

-- Events

RegisterServerEvent('forzar:sendNotify')
AddEventHandler('forzar:sendNotify', function(model, color, street)
    mytype = 'police'
    data = {["code"] = '', ["name"] = 'Robo de ' ..model.. ', color ' ..color.. '.', ["loc"] = street}
    length = 5000
    TriggerClientEvent('forzar:sendNotify', -1, mytype, data, length)
end, false)